class Tool: pass
