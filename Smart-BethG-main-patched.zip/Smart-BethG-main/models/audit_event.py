class AuditEventRecord: pass
